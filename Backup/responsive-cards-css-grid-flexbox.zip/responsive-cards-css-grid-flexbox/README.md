# Responsive Cards CSS Grid/Flexbox 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Taluska/pen/eYvqLgy](https://codepen.io/Taluska/pen/eYvqLgy).

Just testing how could I combine css grid and Flexbox. Let me know if you have some better settings or improvements. 