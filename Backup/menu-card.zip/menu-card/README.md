# Menu Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/VPawar/pen/qBNZaNb](https://codepen.io/VPawar/pen/qBNZaNb).

