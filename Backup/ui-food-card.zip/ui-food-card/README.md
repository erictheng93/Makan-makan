# UI Food Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexpopovich/pen/zZamKQ](https://codepen.io/alexpopovich/pen/zZamKQ).

